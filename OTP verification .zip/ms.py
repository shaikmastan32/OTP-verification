import random
import smtplib
from email.mime.text import MIMEText
from email.mime.multipart import MIMEMultipart


# Step 1: Function to generate a 6-digit OTP
def generate_otp():
    """
    Generates a random 6-digit OTP.
    Returns:
        str: The generated OTP.
    """
    return str(random.randint(100000, 999999))


# Step 2: Function to send OTP via email
def send_otp_to_email(otp, recipient_email):
    """
    Sends the generated OTP to the specified email address using Gmail SMTP.
    
    Args:
        otp (str): The generated OTP.
        recipient_email (str): The recipient's email address.
    """
    # Replace these with your email and App Password
    sender_email = "mastanvali15802@gmail.com"
    sender_password = "gqlm borc uvmn ukzt"

    # Email subject and body
    subject = "Your OTP Verification Code"
    body = f"Hello,\n\nYour OTP for verification is: {otp}\n\nPlease enter this OTP to verify your identity.\n\nThank you!"

    # Create the email message
    msg = MIMEMultipart()
    msg['From'] = sender_email
    msg['To'] = recipient_email
    msg['Subject'] = subject
    msg.attach(MIMEText(body, 'plain'))

    try:
        # Connect to Gmail's SMTP server
        server = smtplib.SMTP('smtp.gmail.com', 587)  # Corrected SMTP server
        server.starttls()  # Start TLS for security
        server.login(sender_email, sender_password)  # Login using sender's credentials

        # Send the email
        server.sendmail(sender_email, recipient_email, msg.as_string())
        server.quit()  # Close the server connection
        print("\n✅ OTP has been sent successfully to your email!")

    except smtplib.SMTPAuthenticationError:
        print("\n⚠️ Error: Authentication failed. Check your email and App Password.")
    except smtplib.SMTPRecipientsRefused:
        print("\n⚠️ Error: Invalid recipient email address.")
    except Exception as e:
        print(f"\n⚠️ Error: Unable to send email. {e}")


# Step 3: Function to verify the entered OTP
def verify_otp(generated_otp, max_attempts=3):
    """
    Verifies the OTP entered by the user.
    
    Args:
        generated_otp (str): The generated OTP to be verified.
        max_attempts (int): Maximum number of allowed attempts for verification.
        
    Returns:
        bool: True if verification succeeds, False otherwise.
    """
    attempts = 0
    while attempts < max_attempts:
        entered_otp = input("\nEnter the OTP sent to your email: ").strip()
        if entered_otp == generated_otp:
            print("\n✅ OTP verified successfully! Access granted.")
            return True
        else:
            attempts += 1
            print(f"❌ Incorrect OTP. You have {max_attempts - attempts} attempt(s) remaining.")
    
    print("\n⛔ Access denied. Too many incorrect attempts.")
    return False


# Step 4: Main function to run the OTP verification system
def main():
    """
    Main function to handle the OTP verification process.
    """
    print("=== Welcome to the OTP Verification System ===\n")

    # Step 4.1: Get the user's email address
    recipient_email = input("Enter your email address: ").strip()

    # Step 4.2: Generate the OTP
    generated_otp = generate_otp()
    print(f"DEBUG: Generated OTP is {generated_otp} (for testing purposes)")  # Remove in production!

    # Step 4.3: Send the OTP to the user's email
    send_otp_to_email(generated_otp, recipient_email)

    # Step 4.4: Verify the OTP entered by the user
    if verify_otp(generated_otp):
        print("\n🎉 Congratulations! You have successfully verified your identity.")
    else:
        print("\n⚠️ Verification failed. Please try again later.")


# Run the main function
if __name__ == "__main__":
   main()
